import React, { useState } from 'react';
import './App.css';

function App() {

  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: ''
  });
  const [editingIndex, setEditingIndex] = useState(null);


  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };


  const handleAddUser = () => {
    if (!formData.firstName || !formData.lastName || !formData.email) {
      alert('Please fill in all fields!');
      return;
    }
    const newUser = { ...formData, id: Date.now() };
    setUsers([...users, newUser]);
    setFormData({ firstName: '', lastName: '', email: '' }); // Reset form
  };


  const handleEditUser = (index) => {
    setFormData(users[index]);
    setEditingIndex(index);
  };


  const handleUpdateUser = () => {
    const updatedUsers = [...users];
    updatedUsers[editingIndex] = formData;
    setUsers(updatedUsers);
    setFormData({ firstName: '', lastName: '', email: '' }); // Reset form
    setEditingIndex(null); // Stop editing
  };


  const handleDeleteUser = (index) => {
    const updatedUsers = users.filter((_, i) => i !== index);
    setUsers(updatedUsers);
  };


  const handleViewUser = (index) => {
    alert(`User Details: ${users[index].firstName} ${users[index].lastName}, Email: ${users[index].email}`);
  };

  return (
    <div className="App">
      <h1>User Management</h1>

      {/* Add New User Form */}
      <div>
        <input
          type="text"
          name="firstName"
          placeholder="First Name"
          value={formData.firstName}
          onChange={handleChange}
        />
        <input
          type="text"
          name="lastName"
          placeholder="Last Name"
          value={formData.lastName}
          onChange={handleChange}
        />
        <input
          type="email"
          name="email"
          placeholder="Email"
          value={formData.email}
          onChange={handleChange}
        />
        {editingIndex === null ? (
          <button onClick={handleAddUser}>Add User</button>
        ) : (
          <button onClick={handleUpdateUser}>Update User</button>
        )}
      </div>

      {/* User List with Actions */}
      <h2>Users List</h2>
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={user.id}>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.email}</td>
              <td>
                <button onClick={() => handleEditUser(index)}>Edit</button>
                <button onClick={() => handleDeleteUser(index)}>Delete</button>
                <button onClick={() => handleViewUser(index)}>View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
