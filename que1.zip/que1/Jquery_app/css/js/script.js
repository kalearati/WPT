
let countryDatabase = [];

$(document).ready(function () {

    $('#saveCountry').click(function () {
        const country = $('#countryInput').val().trim();

        if (country === '') {
            alert('Please enter a country name.');
            return;
        }

        if (countryDatabase.includes(country)) {

            $('#message').text(`${country} saved to the country database.`);
            $('#message').css('color', 'green');
        } else {

            countryDatabase.push(country);
            $('#message').text(`Country name selected: ${country}`);
            $('#message').css('color', 'blue');
        }


        $('#countryInput').val('');
    });
});
