const express = require('express');
const app = express();
const port = 3000;


app.use(express.urlencoded({ extended: true }));


app.get('/form', (req, res) => {
    res.send(`
    <h1>Product Form</h1>
    <form action="/submit" method="POST">
      <label for="productid">Product ID:</label><br>
      <input type="text" id="productid" name="productid" required><br><br>
      
      <label for="productname">Product Name:</label><br>
      <input type="text" id="productname" name="productname" required><br><br>
      
      <label for="price">Price:</label><br>
      <input type="number" id="price" name="price" required><br><br>
      
      <button type="submit">Submit</button>
    </form>
  `);
});


app.post('/submit', (req, res) => {
    const { productid, productname, price } = req.body;

    // Log the received data to the console
    console.log(`Product ID: ${productid}`);
    console.log(`Product Name: ${productname}`);
    console.log(`Price: ${price}`);

    // Return a success message to the client
    res.send('<h1>Success! Your product has been submitted.</h1>');
});


app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
